/* jeu de simulation de vol : un tunnel d�file de droite � gauche*/
/* Un petit vaisseau doit �viter les bords, en le dirigeant avec les fl�ches du clavier */
/* Le vaisseau explose s'il touche un bord du tunnel */
/* Le vaisseau peut tirer un missile devant lui, pour d�truire une pierre */
/* C'EST UN JEU QUE J'AVAIS PROGRAMME EN BASIC, VERS 1987 */

var ecart=2; /* hauteur (2 ou 3) du passage libre dans le tunnel */
var axe=1;   /* variation +1 ou -1 en Y du passage libre */
var alea;  /*valeur aleatoire de 1 � 4 pour deplacer en Y le passage libre */
var ancien=3; /*precedente valeur de alea pour lisser le passage libre*/

var xvaisseau=0; /*coordonn�es du vaisseau*/
var yvaisseau=4;
var direction=0;

var vies=3;
var score=0;
var etatdujeu=0; //0:depart 2:arret  1:jeu ou continue  4:bouton continuer d�j� appuy�

var ipier="images/jpierre.png";  //sources des images
var ivies="images/jvie.png";
var ifond="images/jfond.png";
var ivais="images/jvaisseau.png";

var sondepart=document.getElementById("sond");  //r�f�rences des sons
var songameov=document.getElementById("sono");
var sonbipper=document.getElementById("sonbip");
var sonexplos=document.getElementById("sonboum");
var songere="true";
if ((sondepart.loop)==undefined) songere="false";  //pas de son


/* detection touche du clavier */
document.onkeydown=function(k)
{   
 var touche=k.code;
 if (etatdujeu==4)
   {  
   document.images[(xvaisseau+(yvaisseau*10))].src=ifond;
   if (touche==undefined) touche=k.key;  //mozilla  edge
   if (touche==undefined) touche=k.keyCode;  //ie
   if (touche==undefined) window.event.keyCode;  //chrome,safari
   /* gestion des 4 fleches du clavier */          
   switch(touche)
     {
     case 40:
     case "Down":  
     case "ArrowDown":direction=20;
        if (yvaisseau<7) yvaisseau++;
        vai1=document.images[xvaisseau+(yvaisseau*10)].src;  //verifiera si c'est une pierre
        break;
     case 38:
     case "Up":
     case "ArrowUp":direction=-20;
        if (yvaisseau>1) yvaisseau--;
        vai1=document.images[xvaisseau+(yvaisseau*10)].src;  //verifiera si c'est une pierre
        break;
     case 37:
     case "Left":
     case "ArrowLeft":
        if (xvaisseau>0) xvaisseau--;
        break;
     case 39:
     case "Right":
     case "ArrowRight":
        if (xvaisseau<6) xvaisseau++;
        break;
     default:break;
     }
   } 
}



/* d�marrage du jeu suite � l'appui sur le bouton*/
function lancerdujeu()
{
 xvaisseau=0;
 yvaisseau=4;
 vies=3;
 if(etatdujeu==2) etatdujeu=0;  //jeu arr�t�, puis appui sur (d�marrer)
 if(etatdujeu==0)  //1er appui du bouton d�marrer
   {
   etatdujeu=1;
   score=0;
   document.getElementById("afficheur").style.backgroundColor="cyan";
   document.getElementById("go").style.backgroundColor="grey";
   document.getElementById("repren").style.backgroundColor="grey";
   document.getElementById("stop").style.backgroundColor="lightgreen";
   document.getElementById("afficheur").innerHTML=" Utilisez les fl&egrave;ches du clavier ";
   /* remise � z�ro (jfond.png) de toutes les images */
   for (i=0;i<10;i++)
     for (j=1;j<8;j++)
        document.images[((j*10)+i)].src=ifond;
   for (i=0;i<vies;i++)
     document.images[i].src=ivies;   //replace les images de vies
   vaisseauaffiche();
   colonnedroite();
   reprendrejeu();  //1er d�marrage du jeu
   }
}


/*d�marrage ou reprise */
function reprendrejeu()
{  
 if (etatdujeu==2) //g�re une reprise de jeu en arret,pause
    {
    etatdujeu=1;
      /* change la couleur des boutons, seul (arreter) sera actif*/
    document.getElementById("go").style.backgroundColor="grey";
    document.getElementById("stop").style.backgroundColor="lightgreen";
    document.getElementById("repren").style.backgroundColor="grey";
    document.getElementById("afficheur").innerHTML=" Reprise du jeu ";
    for (i=xvaisseau;i<9;i++)  //efface devant le vaisseau pour reprendre
        {
        document.images[(i+(yvaisseau*10))].src=ifond;
        }
    }
 /* d�clenchement de la cadence de jeu */
 if (etatdujeu==1)
    {
    if (songere=="true") sondepart.play();  //joue le son de depart
    tempori=setInterval(jouer,500);
    etatdujeu=4;  //emp�che le r�appui du bouton (continuer)
    }
}


/* d�cale tout � gauche, affiche le vaisseau, verifie si collision, genere la colonne de droite  */
function jouer()
{
 avancetunnel();
 vaisseauaffiche();
 testecollision();
 colonnedroite();
}


/* arret du jeu avec le clic sur le bouton ou en fin des 3 vies */
function arretdujeu()
{
 if (etatdujeu>0)  /* n'arrete que si on n'avait d�marr� */
    {
    etatdujeu=2; 
    clearInterval(tempori);  /* arret-pause du jeu */
    document.getElementById("go").style.backgroundColor="lightgreen";
    document.getElementById("stop").style.backgroundColor="grey";
    if (vies>0) /* jeu en pause */
       {
       document.getElementById("repren").style.backgroundColor="lightgreen";
       document.getElementById("afficheur").innerHTML=" Jeu mis en pause ";
       }
    }
}

/*gere les vies (x3) */
function gestionvies()
{
 vies--;
 document.images[vies].src=ipier;    /* efface une vie */
 if (vies<1) 
    {
    arretdujeu();   /* partie termin�e */
    if (songere=="true") songameov.play(); 
    document.getElementById("afficheur").innerHTML=" GAME  OVER ";
    document.getElementById("afficheur").style.backgroundColor="orange";
    }
}


/* generation colonne de droite du tunnel, qui sera d�cal�e � gauche */
function colonnedroite()
{ 
  axe=Math.floor((0.5+Math.random())); /*variation de +1 ou -1 */
  if(axe==0) axe=-1; else axe=1;

  ecart=ecart+axe;  //hauteur du tunnel (2 ou 3 cases)
  if (ecart<3) ecart=2; 
     else ecart=3;

  /* alea est la position Y depuis le haut, du passage libre de valeur ecart */
  alea=ancien+axe+Math.floor(0.5-Math.random());
  if(alea<1) alea=1; 
  if(alea>4) alea=4;
  ancien=alea; //garde la valeur de alea pour la prochaine g�n�ration

  /* affiche la colonne de doite : alea*jpierre ecart*jfond restant_8*jpierre */
  for (i=1;i<8;i++)
   {
   if ((i<alea) || (i>(alea+ecart)))
     {
     document.images[(i*10)+9].src=ipier;
     }
    else
     {
     document.images[(i*10)+9].src=ifond;
     }
   } 
}


/* affichage du vaisseau  */
function vaisseauaffiche()
{
 document.images[(xvaisseau)+(yvaisseau*10)].src=ivais;
}


/* d�cale les lignes 1 � 7 d'une colonne vers la gauche */
function avancetunnel()
{
 var anxvais=xvaisseau;  //evite de croiser un d�calage et un mouvement 
 var anyvais=yvaisseau;
 document.images[((anxvais)+(anyvais*10))].src=ifond;  /* eviter de d�caler le jvaisseau */
 for (i=0;i<9;i++)
  {
  for (j=1;j<8;j++)
    {
    /*decale � gauche */
    document.images[((j*10)+i)].src=document.images[((j*10)+i+1)].src;
    }
  }
 score=score+xvaisseau+1;  //affiche le score (1 point par colonne)
 document.getElementById("points").innerHTML="SCORE : "+String(score);
}


/* teste si le vaisseau fonce dans une pierre */
function testecollision()
{ 
 vai2=document.images[(xvaisseau+1+80)].src;  /*reference d'une pierre du bord */
 if (direction==0)
     vai1=document.images[((xvaisseau+1)+(yvaisseau*10))].src; //haut, devant ou bas
 direction=0; /*regarde devant le vaisseau */
 if (vai1===vai2)
  {
  if (songere=="true") sonexplos.play(); 
  document.images[((xvaisseau)+(yvaisseau*10))].src=ifond;
  document.images[((xvaisseau+1)+(yvaisseau*10))].src="images/explosion.gif";
  gestionvies();
  xvaisseau=0;
  yvaisseau=4;
  arretdujeu();  /*mise en pause ou gameover */
  }
}
  


/* modifie le design : ann�es 80 ou 90 ou 2010*/
function modifstyle(st)
{
 if (songere=="true")  sonbipper.play();
 switch(st) 
 {
 case 0:ipier="images/j8pierre.png";
        ifond="images/j8fond.png";
        ivies="images/j8vie.png";
        ivais="images/j8vaisseau.png";
        document.getElementById("an80").style.backgroundColor="yellow";
        document.getElementById("an90").style.backgroundColor="lightgrey";
        document.getElementById("an20").style.backgroundColor="lightgrey";
        break;
 case 1:ipier="images/jpierre.png";
        ifond="images/jfond.png";
        ivies="images/jvie.png";
        ivais="images/jvaisseau.png";
        document.getElementById('an80').style.backgroundColor="lightgrey";
        document.getElementById('an90').style.backgroundColor="cyan";
        document.getElementById('an20').style.backgroundColor="lightgrey";
        break;
 case 2:ipier="images/j2pierre.png";
        ifond="images/j2fond.png";
        ivies="images/j2vie.png";
        ivais="images/j2vaisseau.png";
        document.getElementById('an80').style.backgroundColor="lightgrey";
        document.getElementById('an90').style.backgroundColor="lightgrey";
        document.getElementById('an20').style.backgroundColor="violet";
 }
    /* copie src de ancien pierre */
    ancpier=document.images[4].src;  
    /* change les lignes 0 et 8 */
 for (i=0;i<10;i++)
   {
   if (i<vies)
       document.images[i].src=ivies;
     else
       document.images[i].src=ipier;
   document.images[i+80].src=ipier;
   }
 /* change les lignes 1 � 7, colonne 1 � 9 */
  for (i=0;i<10;i++)
      {
      for (j=1;j<8;j++)
        {
        vai1=document.images[(i+(j*10))].src;
        if (vai1===ancpier)  //ne semble plus utile
            { document.images[(i+(j*10))].src=ipier; }
          else 
            { document.images[(i+(j*10))].src=ifond; }
        }
      }
}       


