/*JAVASCRIPT pour la page 5 : propri�t�s CSS3 */

/* Elements SUBMIT pour valider le formulaire  et RESET */
var formuvalide=document.getElementById("validation");
var formureset=document.getElementById("raz");

/* Element INPUT couleur des boutons */
var colorebouton=document.getElementById("coloris");
var col="#000000"; //couleur fond bouton

/* Element INPUT choix de l'angle du bouton valider */
var anglebouton=document.getElementById("choixangle");
var valrond='0px'; //valeur arrondi bouton

/*Element SELECT choix de l'effet de l'image "imageeffet" */
var imgregler=document.getElementById("choixeffet");
var imgselec=document.getElementById("imageeffet");
/* variable pour cumuler les effets */
var ombr=false;
var opaq=false;
var tour=false;

/* variables pour le choix du d�grad� */
var degrade=0;  

formulaire.curseur.value=14;

/* variable pour la barre de progression */
var progres=pro1=pro2=pro3=pro4=0;


/* effectuer les changements demand�s dans le formulaire */

function reglages()
{ 
/* couleur des 2 boutons : validation et reset */
 col=colorebouton.value;
 formuvalide.style.backgroundColor=col;
 formureset.style.backgroundColor=col;
/* corrige en cas de mauvaise saisie de la couleur */
 if (col<"#000000") 
    {
    col="#000000";
    colorebouton.value="#000000";
    }
 if (col>"#FFFFFF")
    {
    col="#FFFFFF";
    colorebouton.value="#FFFFFF";
    }
/* eclaircit ou assombrit le texte selon le fond des boutons */
 if (col<"#555556") 
    {
    formuvalide.style.color="white";
    formureset.style.color="yellow";
    }
  else 
    {
    formuvalide.style.color="black";
    formureset.style.color="red";
    }

/* arrondi de l'angle des boutons */
 valrond='0px';
 switch (anglebouton.value)
  {
/* nb de px selon le choix du select */
  case '0':valrond='0px';break;
  case '1':valrond='12%';break;
  case '2':valrond='30%';break;
  case '3':valrond='50%';break;
  default:'0px';
  }
 formuvalide.style.borderRadius=valrond;   
 formureset.style.borderRadius=valrond;   


/* g�re l'effet  de l'image */
 switch (imgregler.value)
  {
  /* enleve tous les effets */
  case '0':imgselec.style.boxShadow="";  
           imgselec.style.opacity="1";
           imgselec.style.transform="rotate(0deg)";
           break;
/* le test if permet de mettre ou enlever l'effet ombre */
  case '1':if (ombr==false) {
              imgselec.style.boxShadow="5px 5px 5px blue";
              ombr=true; 
              }
           else {
              imgselec.style.boxShadow="";
              ombr=false 
              }
           break;
/* le test if permet de mettre ou enlever l'effet transparent */
  case '2':if (opaq==false) {
             imgselec.style.opacity="0.35";
              opaq=true; }
           else {
              imgselec.style.opacity="1";
              opaq=false; }
           break;
/* le test if permet de mettre ou enlever l'effet rotation */
  case '3':if (tour==false) {
              imgselec.style.webKitTransform="rotate(10deg)";  /* chrome, safari */
              imgselec.style.transform="rotate(10deg)";
              tour=true; }
            else {
              imgselec.style.transform="rotate(0deg)";
              imgselec.style.webKitTransform="rotate(10deg)";    /* chrome, safari */
              tour=false; }          
            break;
  }


/* choix du type de d�grad� du fond de la page */
degrade=0;
if (formulaire.oriente[1].checked) degrade=1;
if (formulaire.oriente[2].checked) degrade=2;
if (formulaire.oriente[3].checked) degrade=3;

 document.body.style.backgroundImage=formulaire.oriente[degrade].value;
 document.body.style.background= "-ms-"+formulaire.oriente[degrade].value;
 document.body.style.background= "-webkit-"+formulaire.oriente[degrade].value;


/* Choix de la police de tous les textes */
 lapolice=8; //valeur erronnee pour verifier
 for (i=0;i<6;i++) 
   { 
 /* verification de la saisie */
   if ((document.getElementById("choixpolice").value)==(document.getElementById("polices").options[i].value)) lapolice=i;
   }
 if ((document.getElementById("choixpolice").value)=="") lapolice=0;

 if (lapolice==8)
   {
    /* message d'alerte de mauvaise saisie */
   lapolice=0;  //Arial par d�faut
   document.getElementById("erreur").innerHTML="Mauvaise saisie";
   }
   else   document.getElementById("erreur").innerHTML="-";

 document.body.style.fontFamily=document.getElementById("polices").options[lapolice].value;

 taillep=document.getElementById("curseur").value;
 document.body.style.fontSize=String(taillep)+"px";
 document.getElementById("taille").innerHTML=taillep;


/*barre de progression, nb de formulaires valid�s */
 progres=progres+10;
 if (progres>100) progres=100;
 document.getElementById("barre").value=progres;
}




/* barre de progression d'utilisation optimale des formulaires */
function addprogres()
{
 progres=progres+10;

}