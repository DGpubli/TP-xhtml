/*JAVASCRIPT pour le menu d�roulant  int�gr� � chaque page */

var onoff=false;  //sert a derouler ou non le menu


function clicmenu() 
{ 
 if (onoff==false)   /*le menu va se d�rouler */
  {
  onoff=true;
  document.images['bonoff'].src="menu/croix.png"; //pour refermer le menu
  for (i=1;i<8;i++)      
     { 
    /* affiche les boutons de 0 � 6 */
     document.images[i].style.width="auto";
     }
   }
 else /*le menu va se cacher */
   {
   onoff=false;
   document.images['bonoff'].src="menu/menu.png";
   for (i=1;i<8;i++)
      {
      document.images[i].style.width="0px";
      }
   } 
}